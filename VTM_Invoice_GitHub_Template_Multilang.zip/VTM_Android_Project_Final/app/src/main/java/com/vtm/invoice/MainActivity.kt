package com.vtm.invoice

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            InvoiceApp()
        }
    }
}

@Composable
fun InvoiceApp() {
    var invoiceNumber by remember { mutableStateOf("VTM-2025-001") }
    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(id = R.string.app_name)) }) }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp)
        ) {
            Text(stringResource(id = R.string.invoice_number) + ": " + invoiceNumber)
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { /* TODO: Generate PDF */ }) {
                Text(stringResource(id = R.string.generate_invoice))
            }
        }
    }
}
